# Grid Maker - v1.6.1

Premiere Pro 2025+ extension to place timeline clips into a video grid fast.

## Features

- Grid size with two sliders and round `−` / `+` controls: rows x columns (1 to 10)
- Ratio preset selector: `16:9`, `1:1`, `9:16`, `4:5`, `3:2`
- Auto crop effect selection: `Rounded Crop` when the host can resolve it, classic `Crop` fallback otherwise
- Roundness slider with `−` / `+` controls (`%`) for rounded corners in normal + designer workflows (auto-hidden on non-compatible hosts)
- Global margin slider with `−` / `+` controls (px) applied to outer margins and spacing between cells/blocks
- Clickable live grid preview
- One-click placement to a target cell using `Motion`, with `Crop` / `Rounded Crop` when available
- Batch apply: map selected timeline clips to cells in one click, with a persistent `Reverse` toggle for top-to-bottom track order
- Undo for recent Grid Maker actions during the current panel session
- Reset selected clips back to a full-frame 1x1 placement while resetting `Crop` / `Rounded Crop` and Grid Maker-managed `Transform`
- No manual position presets required
- Grid Designer mode (10x10 canvas): irregular layouts with draggable/resizable blocks
- Designer multi-selection with `Shift + click` to move several blocks together, with clearer highlighting on all selected blocks
- Designer multi-selection resize with a shared outer frame and compact handles, while keeping the internal block layout proportional
- Designer block duplication from the selected block, keeping the same size and using free space when available
- Designer alignment tools to center the current selection on the grid
- Designer axis lock while moving blocks with `Shift + drag`
- Designer block order lock toggle (locked by default) so numbering stays stable until you explicitly unlock it
- Designer resize handles on all 4 corners for faster freeform editing
- Create Designer blocks from the currently selected clip visual states (Motion Position/Scale + Crop)
- Designer presets per ratio, saved locally with gallery preview and quick load/delete
- Designer autosave toggle for saving layout edits after changes without manual save clicks
- Designer presets can be duplicated from the active config for faster layout variants
- Designer preset gallery supports drag & drop ordering (order is persisted and no longer reset on save)
- Designer preset import/export in JSON (team sharing + backup)
- Panel state persistence between sessions (reopens the same classic/designer view and UI context)
- UI localization: English (default), French, Spanish, German, Portuguese (Brazil), Japanese, Italian, Chinese (Simplified), Russian
- Premiere Theme Support: panel colors follow Premiere Pro's light and dark interface colors
- Built-in update check against latest GitHub release (with direct ZIP download button when newer version exists)

## Installation

The easiest and safest method is to use the installer scripts included in this repo.

### Windows

Right click on the install-win.bat file and select "Run as administrator".

Or run the following command:

```
cd C:\path\to\PremiereGridMaker
.\install-win.bat
```

### macOS

Launch Terminal and drag and drop the install-macos.sh file into the Terminal window. Then press Enter.

Or run the following commands:
```bash
cd /path/to/PremiereGridMaker
chmod +x ./install-macos.sh
./install-macos.sh
```

### Optional flags

- Install for all users/system scope:
  - Windows: `.\install-win.bat --scope System`
  - macOS: `sudo ./install-macos.sh --scope system`
- Skip debug mode changes:
  - Windows: `.\install-win.bat --skip-debug`
  - macOS: `./install-macos.sh --skip-debug`

## Manual Installation (Fallback)

Use this only if installer scripts are not available.

1. Copy extension files to one CEP extensions path:

- Windows user scope: `C:\Users\<your-user>\AppData\Roaming\Adobe\CEP\extensions\PremiereGridMaker`
- Windows system scope: `C:\Program Files (x86)\Common Files\Adobe\CEP\extensions\PremiereGridMaker`
- macOS user scope: `~/Library/Application Support/Adobe/CEP/extensions/PremiereGridMaker`
- macOS system scope: `/Library/Application Support/Adobe/CEP/extensions/PremiereGridMaker`

2. Enable CEP debug mode:

Windows:
```powershell
8..15 | ForEach-Object { reg add "HKCU\Software\Adobe\CSXS.$_" /v PlayerDebugMode /t REG_SZ /d 1 /f }
```

macOS:
```bash
for v in {8..15}; do defaults write "com.adobe.CSXS.$v" PlayerDebugMode 1; done
```

3. Open Premiere Pro:

- `Window > Extensions > Grid Maker`

## Usage

1. Open a sequence.
2. Select one video clip on timeline.
3. Set rows, columns, and ratio.
4. Optional: adjust global margin (px) and roundness (% when supported).
5. Click a target cell in the preview.

The extension positions/scales the selected clip with `Motion`, then uses a crop effect when the target cell requires cropping.
On Premiere `25.5+`, it prefers `Rounded Crop` when QE can resolve it so corner roundness can be applied; otherwise it falls back to classic `Crop` behavior.

### Batch apply

1. Select multiple video clips in the timeline.
2. Keep the desired grid/designer layout active.
3. Optional: enable `Reverse` to start with the highest selected video track.
4. Click `Apply batch`.

Batch order is deterministic:

- clips are sorted by track from bottom to top (`V1`, then `V2`, etc.),
- with `Reverse` enabled, track order runs from the highest selected track down to the lowest,
- then by timeline start time inside each track.
- in `Grid Designer` mode, target cells are applied in the visible block number order (`1`, `2`, `3`, ...).

### Undo and Reset

- `Undo` restores the previous Motion/Crop/Transform state captured before the last Grid Maker action.
- You can undo several Grid Maker actions in a row while the panel stays open.
- `Reset` applies to selected video clips: it places the clip like a full-frame 1x1 Grid Maker cell, resets Grid Maker-managed `Crop` / `Rounded Crop` values, and restores Grid Maker-managed `Transform` to Premiere's default values.
- Other effects on the clips are left unchanged.

### Designer import/export

- `Autosave`: toggle automatic saving for the active Designer config. When enabled, layout/name/margin/roundness edits are saved shortly after changes.
- `Import Configuration`: merge configs from a `.json` file into local Designer presets.
- `Duplicate config`: copy the active config, append `2` to its name, then select the new copy automatically.
- `Export Configuration`: save all local Designer presets into a shareable `.json` file.
- Empty Designer presets are supported and can be shared/imported as blank templates.

### Designer capture from clip

- In Designer mode, use `Create from clip` to create one or more blocks from the selected timeline clip visible states.
- Select several already-positioned clips before clicking `Create from clip` to create all matching Designer blocks at once.
- Capture reads `Motion` (`Position`, `Scale`) and `Crop`, including asymmetric Crop values.
- Rotation and other advanced effects are intentionally ignored in this capture flow.

### Designer editing

- Use `Shift + click` to add/remove blocks from the current selection.
- Use `Duplicate block` to clone the selected block with the same dimensions.
- Use `Shift + drag` while moving a block to lock movement to the dominant axis.
- Drag any selected block to move the full selection together.
- When several blocks are selected, resize them from one shared outer frame so common sides stay synchronized.
- A simple click on one selected block returns to a single-block selection.
- Outside edit mode, selected blocks keep the clean preview style without the dashed edit overlay.
- Active edit-state toggles (`Edit ON`, `Free ON`, `Order Unlocked`) now share the orange modification color code.
- `Order Locked` keeps the neutral default button style, while `Edit ON` stays orange and `Edit OFF` stays red.
- Use the toolbar above the grid to center the selection horizontally, vertically, or both.
- `Order locked` is enabled by default so block numbering stays stable while editing presets.
- Unlock order only when you intentionally want moved blocks to come to the front and change numbering.

## Premiere Preference Recommendation (Important)

To avoid scale interpretation mismatches (especially in mixed 4K/HD sequences), set:

- `Premiere Pro > Preferences > Media > Default Media Scaling = None` (recommended for deterministic native behavior)

If your team uses a Fit workflow, keep it consistent on all clips before using Grid Maker (do not mix clips with and without frame-fit behavior in the same operation).

## Compatibility

- Host: Adobe Premiere Pro 2025+ (`PPRO 25.0+`)
- `Rounded Crop` + `Roundness` controls: available when the host is `PPRO 25.5+` and QE can resolve the effect (hidden/ignored otherwise)
- OS: Windows and macOS
- Technology: CEP panel + ExtendScript/QE API

## Project Structure

- `CSXS/manifest.xml`: CEP extension manifest
- `index.html`: panel markup
- `css/style.css`: panel styling
- `js/main.js`: UI + CEP bridge + i18n runtime
- `js/i18n-registry.js`: language registry
- `js/locales/*.js`: locale dictionaries
- `jsx/hostscript.jsx`: Premiere ExtendScript logic

## Localization

Localization files are modular and easy to extend:

- `js/i18n-registry.js`: locale registry
- `js/locales/en.js`: English strings
- `js/locales/fr.js`: French strings
- `js/locales/es.js`: Spanish strings
- `js/locales/de.js`: German strings
- `js/locales/pt-BR.js`: Portuguese (Brazil) strings
- `js/locales/ja.js`: Japanese strings
- `js/locales/it.js`: Italian strings
- `js/locales/zh-CN.js`: Chinese (Simplified) strings
- `js/locales/ru.js`: Russian strings

To add a new language, add a new file in `js/locales/` and call:

```js
window.PGM_I18N.registerLocale({
  code: "es",
  flag: "🇪🇸",
  label: "Espanol",
  strings: {
    "app.title": "Grid Maker"
  }
});
```

Then include it in `index.html` before `js/main.js`.

## Changelog

### v1.6.0 - 2026-07-16

- Added Designer autosave, preset duplication, and multi-clip capture from existing timeline layouts.
- Added multi-step Undo and a Reset action that returns selected clips to a clean full-frame placement.
- Improved clip capture accuracy for asymmetric crop values.
- Improved effect insertion reliability and French Premiere Pro compatibility.
- Added automatic Premiere Pro theme support and a clickable version badge for quick access to the product page.

### v1.5.0 - 2026-06-29

- Added a Designer duplication button to clone the selected block with the same size.
- Improved duplicate placement so cloned blocks stay on the same row when space is available.
- Added `Shift + drag` axis lock when moving Designer blocks, including free mode.

### v1.4.0 - 2026-04-20

- Added stronger Grid Designer selection tools with `Shift + click` multi-selection, clearer selection feedback, and quick return to single-block selection.
- Added alignment actions to center the current Designer selection on the grid more easily.
- Added unified multi-block resize with a shared outer frame so several blocks can be resized together while preserving their internal layout.
- Improved Designer interaction reliability after multi-selection work:
  - moving a multi-selection works correctly again
  - non-edit preview stays visually cleaner
  - active Designer toggle colors now follow a clearer edit/modification code.

### v1.3.0

- Added host capability detection (`Rounded Crop` support) to adapt UI controls per Premiere version.
- Added dynamic crop effect strategy:
  - `Rounded Crop` preferred on Premiere `25.5+`
  - classic `Crop` fallback on older/non-compatible hosts.
- Added global `Roundness` slider (`0..100%`) for both classic and designer apply flows.
- Added `roundness` persistence in designer preset save/load/import/export.
- Added drag & drop reordering of Designer preset previews, with persistent order per ratio.
- Added a clear drag & drop insertion indicator (green marker) in Designer preset gallery.
- Updated Designer controls responsive behavior to keep the config action row on one line longer before switching to multi-line layout.
- Added panel/UI state persistence so the extension reopens in the same view (classic or designer) with previous grid settings and panel open/closed state.
- Refined config actions responsive layout to use a deterministic two-row pattern (`New/Name/Save`, then `Import/Export`) before list mode.
- Hardened small-panel layout so Preview stays contained and Debug remains stacked below without overlap.
- Added a compact spacing mode for top controls in Designer mode (ratio, margin/roundness, batch) to reduce vertical footprint.
- Completed `Global margin` localization (`label.margin`) across all supported non-English locales.

### v1.2.6

- Added `Create from clip` in Grid Designer to capture blocks from selected clip visible states (`Motion` position/scale + `Crop`).
- Fixed Designer batch apply ordering to follow visible block numbers (`1`, `2`, `3`, ...) instead of geometric sorting.
- Allowed empty Designer presets (blank drafts/templates), including save/import support.
- Improved Designer actions row compactness so 5 action buttons stay on one line more often.
- Improved Designer responsive layout to prevent overflow/clipping of config action controls on smaller panel widths.
- Fixed `Configs` preset thumbnails overflow on narrow panels and prevented the `Configs` section from vertically clipping preset names.
- Kept small-height behavior on a single global panel scrollbar (instead of local scrolling inside Designer sections).

### v1.2.5

- Added batch apply for selected clips (ordered by track from bottom to top, then by clip start time).
- Added a global margin control (px) for classic grid and designer layouts, with persistence inside designer presets.
- Added designer preset import/export (`Configuration`) to share and back up layouts in JSON.
- Improved localization coverage for the new actions across all supported languages (including batch apply label translations).
- Added high-level inline comments in main panel and host scripts to simplify long-term maintenance.

### v1.2.0

- Added 7 new UI localizations: Spanish, German, Portuguese (Brazil), Japanese, Italian, Chinese (Simplified), Russian.
- Improved small-panel usability with a minimum layout height and vertical scrolling instead of shrinking controls out of view.
- Designer presets gallery is now collapsible (like Debug), with better compact layout and cleaner header behavior.
- Fixed designer preset thumbnail aspect ratio so each saved config preview respects its own ratio (for example `9:16` no longer shown as `16:9`).
- Reduced gallery thumbnail size range and fixed gallery size persistence across Premiere restarts.
- Removed duplicate Debug title in expanded panel (single title source in collapse header).

### v1.1.6

- Switched placement scale computation to strict native mode (no implicit fit-to-frame assumption).
- Added documentation note for `Default Media Scaling` preference to avoid scale mismatches on mixed-resolution timelines.

### v1.1.5

- Added Designer overlap visualization on true intersection areas only (instead of styling the whole block), with clearer overlap badges.
- Improved overlapping-block interaction by keeping selected block on top during edit actions.
- Hardened QE clip targeting by prioritizing selected QE items to avoid cross-track effect insertion mismatches.
- Stabilized effect ensure flow by requiring real clip component visibility before continuing placement.
- Enforced `Transform > Uniform Scale` activation with explicit toggle fallback to improve default Transform behavior after automatic insertion.

### v1.1.4

- Fixed QE clip targeting across duplicated clips on multiple tracks by strongly prioritizing the selected track during QE matching.
- Improved track index resolution using parent track, clip identity, and nodeId fallback checks.
- Reduced host-side insertion latency by removing long settle waits while keeping duplicate-add protection.
- Disabled UI auto-retry loop for apply requests to keep interactions immediate and deterministic.

### v1.1.3

- Stabilized effect insertion flow to prevent duplicate `Transform`/`Crop` additions when Premiere/QE effect visibility is delayed.
- Added queued apply requests in panel UI to avoid overlapping host calls during rapid cell clicks.
- Added short auto-retry for transient `transform_effect_unavailable` / `crop_effect_unavailable` responses.
- Improved debug traces with QE effect counts before/after insertion attempts.

### v1.1.2

- Enforced strict placement pipeline: Motion for size/position, Transform effect always required (neutral, no parameter writes).
- Improved universal Transform detection and stabilization after effect insertion to reduce QE timing issues.
- Kept crop path strictly on Crop effect components (never Motion-integrated crop behavior).

### v1.1.1

- Fixed intermittent `crop_effect_unavailable` failures caused by delayed QE effect visibility after `addVideoEffect`.
- Improved effect detection stabilization with short retries before concluding that Crop is unavailable.
- Enforced crop handling to use Crop effect components only (never Motion-integrated crop behavior).
- Avoided hard failure when computed crop is zero and Crop effect is unavailable (placement can still succeed).

### v1.1.0

- Added full `Grid Designer` mode with irregular block layouts on a `10x10` canvas.
- Added drag/drop + resize editing flow with `Edit ON/OFF` state and stronger visual feedback.
- Added local designer preset storage by ratio, with gallery preview, quick load, delete, and size slider.
- Added custom-cell host placement API for designer blocks with normalized bounds.
- Increased classic grid limits from `8x8` to `10x10` in UI and placement validation.
- Improved classic preview responsiveness in small panels (compact rendering and tighter spacing).

### v1.0.6

- Fixed scale computation when source and sequence ratios differ (notably `9:16` and `1:1` timelines).
- Grid cell fill is now consistent with crop direction rules, including Motion normalized workflows.
- Added stronger QE/native-size diagnostics to stabilize placement behavior.

### v1.0.5

- Fixed update banner download action by aligning URL opening with the same CEP method used in other Premiere panels.
- Added stronger fallback chain for opening update download URLs.

### v1.0.4

- Fixed update banner click behavior so direct ZIP download URLs open reliably.
- Improved update URL handling for GitHub release download variants (including query string forms).

### v1.0.3

- Improved clip fill behavior by grid cell orientation:
  - Portrait and square cells prioritize full-height fill (crop left/right)
  - Landscape cells prioritize full-width fill (crop top/bottom)
- Improved preview responsiveness in the panel:
  - Preview always fits inside available space
  - No overflow in vertical ratios like `9:16` (letterbox/pillarbox when needed)
